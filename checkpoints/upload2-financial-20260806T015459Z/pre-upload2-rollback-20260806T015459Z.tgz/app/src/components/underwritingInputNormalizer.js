function isMissingValue(value) {
  if (value === null || value === undefined || value === "") return true;
  if (typeof value === "number") return !Number.isFinite(value);
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (!trimmed) return true;
    return /^(n\/a|na|none|null|undefined|nan)$/i.test(trimmed);
  }
  return false;
}

function resolveValue(deal = {}, keys = []) {
  for (const key of keys) {
    const value = deal[key];
    if (!isMissingValue(value)) return value;
  }
  return null;
}

function parseCurrencyValue(value) {
  if (isMissingValue(value)) return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value === "string") {
    const trimmed = value.trim();
    const normalized = trimmed.replace(/[$,\s]/g, "").replace(/%/g, "");
    if (!normalized) return null;
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

function parsePercentValue(value) {
  if (isMissingValue(value)) return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value === "string") {
    const trimmed = value.trim();
    const normalized = trimmed.replace(/[$,\s]/g, "").replace(/%/g, "");
    if (!normalized) return null;
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

function parseIntegerValue(value) {
  if (isMissingValue(value)) return null;
  if (typeof value === "number") return Number.isInteger(value) ? value : null;
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (!trimmed) return null;
    const parsed = Number(trimmed.replace(/[$,\s]/g, ""));
    return Number.isInteger(parsed) ? parsed : null;
  }
  return null;
}

function buildMissingFlags(values = {}) {
  const missingFlags = {};
  Object.entries(values).forEach(([key, value]) => {
    missingFlags[`${key}Missing`] = isMissingValue(value);
  });
  return missingFlags;
}

export function normalizeUnderwritingInputs(deal = {}) {
  const purchasePrice = parseCurrencyValue(resolveValue(deal, ["purchasePrice", "askingPrice", "listPrice", "currentOfferPrice"]));
  const rehabBudget = parseCurrencyValue(resolveValue(deal, ["rehabBudget", "repairBudget", "renovationBudget", "rehabCost"]));
  const arv = parseCurrencyValue(resolveValue(deal, ["estimatedArv", "arv", "projectedARV", "supportedARV", "currentValue", "marketValue", "estimatedValue"]));
  const annualTaxes = parseCurrencyValue(resolveValue(deal, ["annualTaxes", "taxes", "propertyTaxes"]));
  const annualInsurance = parseCurrencyValue(resolveValue(deal, ["annualInsurance", "insurance"]));
  const holdingMonths = parseIntegerValue(resolveValue(deal, ["holdingMonths", "holdMonths", "projectHoldMonths"]));
  const annualInterestRate = parsePercentValue(resolveValue(deal, ["annualInterestRate", "interestRate", "rate"]));
  const actualLoanAmount = parseCurrencyValue(resolveValue(deal, ["actualLoanAmount", "actualLoan", "loanAmount", "fundingAmount"]));
  const lenderLoanAmount = parseCurrencyValue(resolveValue(deal, ["lenderLoanAmount", "lenderLoan", "loanAmountFromLender"]));
  const acquisitionLoan = parseCurrencyValue(resolveValue(deal, ["acquisitionLoan", "purchaseLoan", "acquisitionFunding"]));
  const fundedRehab = parseCurrencyValue(resolveValue(deal, ["fundedRehab", "rehabFunding", "rehabLoan"]));
  const cashToClose = parseCurrencyValue(resolveValue(deal, ["cashToClose", "cashToCloseAmount"]));
  const earnestMoney = parseCurrencyValue(resolveValue(deal, ["earnestMoney"]));
  const totalInitialCashInvested = parseCurrencyValue(resolveValue(deal, ["totalInitialCashInvested", "initialCashInvested", "cashInvested"]));
  const constructionHoldback = parseCurrencyValue(resolveValue(deal, ["constructionHoldback", "holdbackAmount", "constructionHoldbackAmount"]));
  const acquisitionClosingCosts = parseCurrencyValue(resolveValue(deal, ["acquisitionClosingCosts", "closingCosts", "closingCost", "purchaseClosingCosts", "acquisitionClosingCost", "purchaseClosingCost"]));
  const originationFee = parseCurrencyValue(resolveValue(deal, ["originationFee", "originationFees"]));
  const brokerFee = parseCurrencyValue(resolveValue(deal, ["brokerFee"]));
  const underwritingFee = parseCurrencyValue(resolveValue(deal, ["underwritingFee"]));
  const servicingFee = parseCurrencyValue(resolveValue(deal, ["servicingFee"]));
  const lenderLegalFee = parseCurrencyValue(resolveValue(deal, ["lenderLegalFee", "legalFee"]));
  const monitoringFee = parseCurrencyValue(resolveValue(deal, ["monitoringFee"]));
  const otherLenderFees = parseCurrencyValue(resolveValue(deal, ["otherLenderFees", "otherFees"]));
  const manualFinancingCosts = parseCurrencyValue(resolveValue(deal, ["financingCosts", "financingCost", "manualFinancingCosts", "overrideFinancingCosts"]));
  const sellingCostPercent = parsePercentValue(resolveValue(deal, ["sellingCostPercent", "saleCostPercent", "sellerCostPercent"]));
  const sellerConcessions = parseCurrencyValue(resolveValue(deal, ["sellerConcessions", "sellerConcession"]));
  const fixedSaleCosts = parseCurrencyValue(resolveValue(deal, ["fixedSaleCosts", "saleCosts", "fixedSellingCosts"]));
  const outOfPocketRehab = parseCurrencyValue(resolveValue(deal, ["outOfPocketRehab", "rehabOutOfPocket", "rehabCash"]));
  const outOfPocketHoldingCosts = parseCurrencyValue(resolveValue(deal, ["outOfPocketHoldingCosts", "holdingCostsOutOfPocket", "owningCosts"]));
  const otherRequiredEquity = parseCurrencyValue(resolveValue(deal, ["otherRequiredEquity", "additionalEquity"]));
  const fundedRehabDraws = parseCurrencyValue(resolveValue(deal, ["fundedRehabDraws", "rehabDraws"]));
  const lenderPaidEligibleCosts = parseCurrencyValue(resolveValue(deal, ["lenderPaidEligibleCosts", "lenderPaidCosts"]));
  const creditsApplied = parseCurrencyValue(resolveValue(deal, ["creditsApplied", "credits"]));
  const loanTermMonths = parseIntegerValue(resolveValue(deal, ["loanTermMonths", "loanTerm", "termMonths"]));
  const amortizationTermMonths = parseIntegerValue(resolveValue(deal, ["amortizationTermMonths", "amortizationTerm"]));
  const paymentType = resolveValue(deal, ["paymentType", "loanPaymentType", "debtPaymentType"]);
  const financingCostsIncludeClosingCosts = Boolean(resolveValue(deal, ["financingCostsIncludeClosingCosts", "loanIncludesClosingCosts", "financedClosingCosts", "financedEligibleCosts", "includeClosingCostsInFinancing"]));
  const acquisitionLoanAmount = parseCurrencyValue(resolveValue(deal, ["acquisitionLoanAmount", "acquisitionLoan", "purchaseLoan", "acquisitionFunding"]));
  const rehabFundingAmount = parseCurrencyValue(resolveValue(deal, ["rehabFundingAmount", "rehabFunding", "rehabLoan", "fundedRehab"]));
  const isAlreadyAcquired = Boolean(resolveValue(deal, ["isAcquired", "alreadyAcquired", "acquired", "dealStatus"]) || (deal.status && /acquired|owned|completed/i.test(String(deal.status))));
  const values = {
    purchasePrice,
    rehabBudget,
    arv,
    annualTaxes,
    annualInsurance,
    holdingMonths,
    annualInterestRate,
    actualLoanAmount,
    lenderLoanAmount,
    acquisitionLoan,
    fundedRehab,
    cashToClose,
    earnestMoney,
    totalInitialCashInvested,
    constructionHoldback,
    acquisitionClosingCosts,
    originationFee,
    brokerFee,
    underwritingFee,
    servicingFee,
    lenderLegalFee,
    monitoringFee,
    otherLenderFees,
    manualFinancingCosts,
    sellingCostPercent,
    sellerConcessions,
    fixedSaleCosts,
    outOfPocketRehab,
    outOfPocketHoldingCosts,
    otherRequiredEquity,
    fundedRehabDraws,
    lenderPaidEligibleCosts,
    creditsApplied,
    loanTermMonths,
    amortizationTermMonths,
    paymentType,
    financingCostsIncludeClosingCosts,
    acquisitionLoanAmount,
    rehabFundingAmount,
    isAlreadyAcquired,
  };

  const missingFlags = buildMissingFlags(values);
  const missingFields = Object.entries(missingFlags).filter(([, isMissing]) => isMissing).map(([key]) => key.replace(/Missing$/, ""));

  return {
    ...values,
    missingFields,
    missingFlags,
    hasMissingData: missingFields.length > 0,
  };
}
